package Mpp.Lab2.prob2B;

public class OrderLine {
}
