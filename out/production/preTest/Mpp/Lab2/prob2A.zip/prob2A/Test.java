package Mpp.Lab2.prob2A;

public class Test {
    public static void main(String[] args) {
        Student student = StudentGradeReportFactory.creatStudent("Yan Zhao");
        System.out.println(student.getName());
    }
}
