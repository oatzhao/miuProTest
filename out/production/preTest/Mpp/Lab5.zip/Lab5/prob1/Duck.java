package Mpp.Lab5.prob1;

abstract public class Duck implements FlyBehavior, QuackBehavior{
    public abstract void swim();
    public abstract void diplay();
}
