package Mpp.Lab5.prob1;

public interface FlyBehavior {
    public void fly();
}
