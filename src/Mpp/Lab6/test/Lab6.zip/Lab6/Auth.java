package Mpp.Lab6.test.Lab6;

import java.io.Serializable;

public enum Auth implements Serializable {
	MEMBER, SELLER, BOTH;
}
