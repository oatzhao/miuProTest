package Mpp.Lab3.prob4;

public class Trailer extends Building{
    public double computeRent(){
        return 500;
    }
}
