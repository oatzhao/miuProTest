package Mpp.Lab3.prob4;

public class Building {
    private double rent;

    public double computeRent(){
        return 0.0;
    }
}
