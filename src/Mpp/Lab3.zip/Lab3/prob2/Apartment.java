package Mpp.Lab3.prob2;

public class Apartment {
    private int price;
    Apartment(int price){
        this.price = price;
    }

    public int getPrice(){
        return price;
    }
}
