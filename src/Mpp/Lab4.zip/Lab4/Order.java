package Mpp.Lab4;

import java.time.LocalDate;

public class Order {
    private String orderNo;
    private LocalDate date;
    private int orderAmount;
}
