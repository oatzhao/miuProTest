package Mpp.Lab4;

public class Salaried extends Employee{
    private double salary;

    public double calcGrossPay(){
        return salary;
    }
}
